# ChinaList2.0_Backup

Chrome浏览器插件：广告净化器、广告防御者的内置规则

此为作者弃坑时的最新规则。弃坑原因：http://bbs.huorong.cn/thread-66108-1-1.html